package softuni.shop.domain.models.category;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryModel {
    private String name;
}
